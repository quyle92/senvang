<?php
$tungay = date('d-m-Y');
//$tungay = substr($tungay,6) . "/" . substr($tungay,3,2) . "/" . substr($tungay,0,2);

$denNgay = date('d-m-Y');
//$denngay = substr($denngay,6) . "/" . substr($denngay,3,2) . "/" . substr($denngay,0,2);

$tugio =  isset( $_POST['tugio'] ) ? $_POST['tugio'] :"";
if ($tugio == '' || $tugio == null) $tugio = "00:01";

$dengio =  isset( $_POST['dengio'] ) ? $_POST['dengio'] :"";
if ($dengio == '' || $dengio == null) $dengio = "23:00";

$khu = $massagevl->getKhu();
$ma_khu_abbr_arr = array();

for ($i = 0; $i < sqlsrv_num_rows($khu); $i++) 
{  
  $r = sqlsrv_fetch_array($khu, SQLSRV_FETCH_ASSOC , SQLSRV_SCROLL_ABSOLUTE, $i);

  $ma_khu_abbr_arr[] = $r['MK'];
}
?>

<form action="" method="post" id="occupied-tables">
  <div class="row">
      	<div class="col-md-2" style="margin-bottom:5px">Từ ngày:</div>
	        <div class="col-md-3" style="margin-bottom:5px"><input name="tungay" type="text"  value="<?=@$tungay?>" id="tungay" /></div>
	        <div class="col-md-2" style="margin-bottom:5px">Từ giờ: </div>
	        <div class="col-md-3" style="margin-bottom:5px"><input name="tugio" type="time"  value="<?=($tugio) ? $tugio : ""?>" id="tugio" /></div>
        <div class="col-md-2" style="margin-bottom:5px"></div>
	</div>
	<div class="row">
      	<div class="col-md-2" style="margin-bottom:5px">Đến ngày:</div>
	        <div class="col-md-3" style="margin-bottom:5px"><input name="denngay" type="text"  value="<?=@$denngay?>" id="denngay" /></div>
	        <div class="col-md-2" style="margin-bottom:5px">Đến giờ: </div>
	        <div class="col-md-3" style="margin-bottom:5px"><input name="dengio" type="time"  value="<?php echo @$dengio ?>" id="dengio" /></div>
        <div class="col-md-2" style="margin-bottom:5px"><input type="submit" value="Lọc"></div>
	</div>
</form>

<div class="container-fluid">
<?php
$khu = $massagevl->getKhu();
for ($i = 0; $i < sqlsrv_num_rows($khu); $i++) 
{  $r = sqlsrv_fetch_array($khu, SQLSRV_FETCH_ASSOC , SQLSRV_SCROLL_ABSOLUTE, $i);
  $ma_khu = $r['MaKhu'];
  $ten_khu = $r['MoTa'];
  include('occupied-tables/' . $r['MaKhu'] . '.php');
} 
?>
</div>

<script>

  $('form#occupied-tables').on('submit', function (event){
    event.preventDefault();

    var formValues= $(this).serialize();console.log(formValues);
   
    $.ajax({
    url:"occupied-tables/ajax/process.php",
    method:"POST",
    //data:{'tu-ngay' : tuNgay, 'den-ngay' : denNgay},
    data:formValues,
    dataType:"json",
    success:function(response)
      { 
      
        //FOOT
        const DOPHU_KHAC_FOOT = document.getElementById('dophu_khac_01-FT');

        var banTrong_FT = response[0].FT.ban_trong;
        var coNguoi_FT = response[0].FT.co_nguoi; 

        var data_FT = {
          labels: ["Bàn trống",  "Có người"],
          datasets: [
            {
              label: "Tỉ lệ bàn có người",
              data: [banTrong_FT, coNguoi_FT],
              backgroundColor: [
                "#DC143C",
                "#2E8B57"
              ],
              borderColor: [
                "#CB252B",
                "#1D7A46"
              ],
              borderWidth: [1, 1]
            }
          ]
        };

        var options_FT = {
          responsive: true,
          title: {
            display: true,
            position: "top",
            text: "FOOT",
            fontSize: 18,
            fontColor: "#111"
          },
          legend: {
            display: false,
            position: "bottom",
            labels: {
              fontColor: "#333",
              fontSize: 16
            }
          },
            plugins: {
              datalabels: {
                  formatter: (value, DOPHU_KHAC_FOOT) => {
                      let sum = 0;
                      let dataArr = DOPHU_KHAC_FOOT.chart.data.datasets[0].data;
                      dataArr.map(data => {
                          sum += data;
                      });
                      let percentage = (value*100 / sum).toFixed(2)+"%";
                      return percentage;
                  },
                  color: '#fff',
                  
              }
          },
          legendCallback: function(chart) {
           var ul = document.createElement('ul');
           var backgroundColor = chart.data.datasets[0].backgroundColor;
           var value = chart.data.datasets[0].data;
           chart.data.labels.forEach(function(label, index) {
              ul.innerHTML += `
                <li>
                    <span style="background-color: ${backgroundColor[index]}"></span>
                    ${label}:  ${value[index]}
                 </li>
              `; // ^ ES6 Template String
           });
           return ul.outerHTML;
        }
        };

      var myPieChart  = new Chart(DOPHU_KHAC_FOOT, {
          type: 'doughnut',
          data: data_FT,
          options: options_FT
      });
      //document.getElementById('chart-legends').innerHTML = myPieChart.generateLegend();
      $("#chart_legends_filter_01-FT").html(myPieChart.generateLegend());
      console.log(Chart.defaults.global);
      console.log(myPieChart);


      //HOTEL
      const DOPHU_KHAC_HOTEL = document.getElementById('dophu_khac_01-HT');

        var banTrong_HT = response[1].HT.ban_trong;
        var coNguoi_HT = response[1].HT.co_nguoi; 

        var data_HT = {
          labels: ["Bàn trống",  "Có người"],
          datasets: [
            {
              label: "Tỉ lệ bàn có người",
              data: [banTrong_HT, coNguoi_HT],
              backgroundColor: [
                "#DC143C",
                "#2E8B57"
              ],
              borderColor: [
                "#CB252B",
                "#1D7A46"
              ],
              borderWidth: [1, 1]
            }
          ]
        };

        var options_HT = {
          responsive: true,
          title: {
            display: true,
            position: "top",
            text: "KHÁCH SẠN",
            fontSize: 18,
            fontColor: "#111"
          },
          legend: {
            display: false,
            position: "bottom",
            labels: {
              fontColor: "#333",
              fontSize: 16
            }
          },
            plugins: {
              datalabels: {
                  formatter: (value, DOPHU_KHAC_HOTEL) => {
                      let sum = 0;
                      let dataArr = DOPHU_KHAC_HOTEL.chart.data.datasets[0].data;
                      dataArr.map(data => {
                          sum += data;
                      });
                      let percentage = (value*100 / sum).toFixed(2)+"%";
                      return percentage;
                  },
                  color: '#fff',
                  
              }
          },
          legendCallback: function(chart) {
           var ul = document.createElement('ul');
           var backgroundColor = chart.data.datasets[0].backgroundColor;
           var value = chart.data.datasets[0].data;
           chart.data.labels.forEach(function(label, index) {
              ul.innerHTML += `
                <li>
                    <span style="background-color: ${backgroundColor[index]}"></span>
                    ${label}:  ${value[index]}
                 </li>
              `; // ^ ES6 Template String
           });
           return ul.outerHTML;
        }
        };

      var myPieChart  = new Chart(DOPHU_KHAC_HOTEL, {
          type: 'doughnut',
          data: data_HT,
          options: options_HT
      });
      //document.getElementById('chart-legends').innerHTML = myPieChart.generateLegend();
      $("#chart_legends_filter_01-HT").html(myPieChart.generateLegend());

       //KEY_SUPPER_VIP
      const DOPHU_KHAC_KEY_SUPPER_VIP = document.getElementById('dophu_khac_01-LT4');

        var banTrong_KSV = response[2].LT4.ban_trong;
        var coNguoi_KSV = response[2].LT4.co_nguoi; 

        var data_KSV = {
          labels: ["Bàn trống",  "Có người"],
          datasets: [
            {
              label: "Tỉ lệ bàn có người",
              data: [banTrong_KSV, coNguoi_KSV],
              backgroundColor: [
                "#DC143C",
                "#2E8B57"
              ],
              borderColor: [
                "#CB252B",
                "#1D7A46"
              ],
              borderWidth: [1, 1]
            }
          ]
        };

        var options_KSV = {
          responsive: true,
          title: {
            display: true,
            position: "top",
            text: "KEY SUPPER VIP",
            fontSize: 18,
            fontColor: "#111"
          },
          legend: {
            display: false,
            position: "bottom",
            labels: {
              fontColor: "#333",
              fontSize: 16
            }
          },
            plugins: {
              datalabels: {
                  formatter: (value, DOPHU_KHAC_KEY_SUPPER_VIP) => {
                      let sum = 0;
                      let dataArr = DOPHU_KHAC_KEY_SUPPER_VIP.chart.data.datasets[0].data;
                      dataArr.map(data => {
                          sum += data;
                      });
                      let percentage = (value*100 / sum).toFixed(2)+"%";
                      return percentage;
                  },
                  color: '#fff',
                  
              }
          },
          legendCallback: function(chart) {
           var ul = document.createElement('ul');
           var backgroundColor = chart.data.datasets[0].backgroundColor;
           var value = chart.data.datasets[0].data;
           chart.data.labels.forEach(function(label, index) {
              ul.innerHTML += `
                <li>
                    <span style="background-color: ${backgroundColor[index]}"></span>
                    ${label}:  ${value[index]}
                 </li>
              `; // ^ ES6 Template String
           });
           return ul.outerHTML;
        }
        };

      var myPieChart  = new Chart(DOPHU_KHAC_KEY_SUPPER_VIP, {
          type: 'doughnut',
          data: data_KSV,
          options: options_KSV
      });
      //document.getElementById('chart-legends').innerHTML = myPieChart.generateLegend();
      $("#chart_legends_filter_01-LT4").html(myPieChart.generateLegend());

      //PHÒNG THƯỜNG
      const DOPHU_KHAC_MS= document.getElementById('dophu_khac_01-MS');

        var banTrong_MS = response[3].MS.ban_trong;
        var coNguoi_MS = response[3].MS.co_nguoi; 

        var data_MS = {
          labels: ["Bàn trống",  "Có người"],
          datasets: [
            {
              label: "Tỉ lệ bàn có người",
              data: [banTrong_MS, coNguoi_MS],
              backgroundColor: [
                "#DC143C",
                "#2E8B57"
              ],
              borderColor: [
                "#CB252B",
                "#1D7A46"
              ],
              borderWidth: [1, 1]
            }
          ]
        };

        var options_MS = {
          responsive: true,
          title: {
            display: true,
            position: "top",
            text: "PHÒNG THƯỜNG",
            fontSize: 18,
            fontColor: "#111"
          },
          legend: {
            display: false,
            position: "bottom",
            labels: {
              fontColor: "#333",
              fontSize: 16
            }
          },
            plugins: {
              datalabels: {
                  formatter: (value, DOPHU_KHAC_MS) => {
                      let sum = 0;
                      let dataArr = DOPHU_KHAC_MS.chart.data.datasets[0].data;
                      dataArr.map(data => {
                          sum += data;
                      });
                      let percentage = (value*100 / sum).toFixed(2)+"%";
                      return percentage;
                  },
                  color: '#fff',
                  
              }
          },
          legendCallback: function(chart) {
           var ul = document.createElement('ul');
           var backgroundColor = chart.data.datasets[0].backgroundColor;
           var value = chart.data.datasets[0].data;
           chart.data.labels.forEach(function(label, index) {
              ul.innerHTML += `
                <li>
                    <span style="background-color: ${backgroundColor[index]}"></span>
                    ${label}:  ${value[index]}
                 </li>
              `; // ^ ES6 Template String
           });
           return ul.outerHTML;
        }
        };

      var myPieChart  = new Chart(DOPHU_KHAC_MS, {
          type: 'doughnut',
          data: data_MS,
          options: options_MS
      });
      //document.getElementById('chart-legends').innerHTML = myPieChart.generateLegend();
      $("#chart_legends_filter_01-VIP1").html(myPieChart.generateLegend());

      //PHÒNG LẦU 1
      const DOPHU_KHAC_KEY_VIP1= document.getElementById('dophu_khac_01-VIP1');

        var banTrong_VIP1 = response[4].VIP1.ban_trong;
        var coNguoi_VIP1 = response[4].VIP1.co_nguoi; 

        var data_VIP1 = {
          labels: ["Bàn trống",  "Có người"],
          datasets: [
            {
              label: "Tỉ lệ bàn có người",
              data: [banTrong_VIP1, coNguoi_VIP1],
              backgroundColor: [
                "#DC143C",
                "#2E8B57"
              ],
              borderColor: [
                "#CB252B",
                "#1D7A46"
              ],
              borderWidth: [1, 1]
            }
          ]
        };

        var options_VIP1 = {
          responsive: true,
          title: {
            display: true,
            position: "top",
            text: "PHÒNG LẦU 1",
            fontSize: 18,
            fontColor: "#111"
          },
          legend: {
            display: false,
            position: "bottom",
            labels: {
              fontColor: "#333",
              fontSize: 16
            }
          },
            plugins: {
              datalabels: {
                  formatter: (value, DOPHU_KHAC_KEY_VIP1) => {
                      let sum = 0;
                      let dataArr = DOPHU_KHAC_KEY_VIP1.chart.data.datasets[0].data;
                      dataArr.map(data => {
                          sum += data;
                      });
                      let percentage = (value*100 / sum).toFixed(2)+"%";
                      return percentage;
                  },
                  color: '#fff',
                  
              }
          },
          legendCallback: function(chart) {
           var ul = document.createElement('ul');
           var backgroundColor = chart.data.datasets[0].backgroundColor;
           var value = chart.data.datasets[0].data;
           chart.data.labels.forEach(function(label, index) {
              ul.innerHTML += `
                <li>
                    <span style="background-color: ${backgroundColor[index]}"></span>
                    ${label}:  ${value[index]}
                 </li>
              `; // ^ ES6 Template String
           });
           return ul.outerHTML;
        }
        };

      var myPieChart  = new Chart(DOPHU_KHAC_KEY_VIP1, {
          type: 'doughnut',
          data: data_VIP1,
          options: options_VIP1
      });
      //document.getElementById('chart-legends').innerHTML = myPieChart.generateLegend();
      $("#chart_legends_filter_01-VIP1").html(myPieChart.generateLegend());

      //PHÒNG LẦU 4
      const DOPHU_KHAC_KEY_VIP2= document.getElementById('dophu_khac_01-VIP2');

        var banTrong_VIP2 = response[5].VIP2.ban_trong;
        var coNguoi_VIP2 = response[5].VIP2.co_nguoi; 

        var data_VIP2 = {
          labels: ["Bàn trống",  "Có người"],
          datasets: [
            {
              label: "Tỉ lệ bàn có người",
              data: [banTrong_VIP2, coNguoi_VIP2],
              backgroundColor: [
                "#DC143C",
                "#2E8B57"
              ],
              borderColor: [
                "#CB252B",
                "#1D7A46"
              ],
              borderWidth: [1, 1]
            }
          ]
        };

        var options_VIP2 = {
          responsive: true,
          title: {
            display: true,
            position: "top",
            text: "PHÒNG LẦU 4",
            fontSize: 18,
            fontColor: "#111"
          },
          legend: {
            display: false,
            position: "bottom",
            labels: {
              fontColor: "#333",
              fontSize: 16
            }
          },
            plugins: {
              datalabels: {
                  formatter: (value, DOPHU_KHAC_KEY_VIP2) => {
                      let sum = 0;
                      let dataArr = DOPHU_KHAC_KEY_VIP2.chart.data.datasets[0].data;
                      dataArr.map(data => {
                          sum += data;
                      });
                      let percentage = (value*100 / sum).toFixed(2)+"%";
                      return percentage;
                  },
                  color: '#fff',
                  
              }
          },
          legendCallback: function(chart) {
           var ul = document.createElement('ul');
           var backgroundColor = chart.data.datasets[0].backgroundColor;
           var value = chart.data.datasets[0].data;
           chart.data.labels.forEach(function(label, index) {
              ul.innerHTML += `
                <li>
                    <span style="background-color: ${backgroundColor[index]}"></span>
                    ${label}:  ${value[index]}
                 </li>
              `; // ^ ES6 Template String
           });
           return ul.outerHTML;
        }
        };

      var myPieChart  = new Chart(DOPHU_KHAC_KEY_VIP2, {
          type: 'doughnut',
          data: data_VIP2,
          options: options_VIP2
      });
      //document.getElementById('chart-legends').innerHTML = myPieChart.generateLegend();
      $("#chart_legends_filter_01-VIP2").html(myPieChart.generateLegend());


    }
  });
});

</script>