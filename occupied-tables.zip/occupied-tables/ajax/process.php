<?php
require("../../lib/db.php");
require("../../lib/MassageVL.php");
@session_start();
$massagevl = new MassageVL;

$tungay = isset( $_POST['tungay'] ) ? $_POST['tungay'] :"";//16/10/2020
$tungay = substr($tungay,6) . "/" . substr($tungay,3,2) . "/" . substr($tungay,0,2);

$denngay = isset( $_POST['denngay'] ) ? $_POST['denngay'] :"";
$denngay = substr($denngay,6) . "/" . substr($denngay,3,2) . "/" . substr($denngay,0,2);

$tugio =  isset( $_POST['tugio'] ) ? $_POST['tugio'] :"";
if ($tugio == '' || $tugio == null) $tugio = "00:01";

$dengio =  isset( $_POST['dengio'] ) ? $_POST['dengio'] :"";
if ($dengio == '' || $dengio == null) $dengio = "23:00";

$khu = $massagevl->getKhu();
$output = array();

for ($i = 0; $i < sqlsrv_num_rows($khu); $i++) 
{  
	$r = sqlsrv_fetch_array($khu, SQLSRV_FETCH_ASSOC , SQLSRV_SCROLL_ABSOLUTE, $i);

	$ma_khu = $r['MaKhu'];
	$co_nguoi = $massagevl->getTotalTablesWithBills( $tungay, $denngay, $tugio, $dengio, $ma_khu);
	$tong_so_ban = $massagevl->countTotalTables( $ma_khu );
	$ban_trong = $tong_so_ban - $co_nguoi;

	$output[] = [
		$r['MK'] => array(
			'co_nguoi' => $co_nguoi,
			'ban_trong' => $ban_trong
		)
	];
}

echo json_encode($output);