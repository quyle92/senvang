<div class="row">
    <div class="col-md-12" >
      <canvas id="dophu_khac_<?=$ma_khu?>" ></canvas>
    </div>
</div>
<div class="row">
    <div class="col-md-12" >
      <div id="chart_legends_filter_<?=$ma_khu?>" ></div>
    </div>
</div>

